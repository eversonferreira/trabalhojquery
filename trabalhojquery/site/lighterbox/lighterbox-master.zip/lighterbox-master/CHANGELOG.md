# lighterbox changelog

## 0.0.3

- Added better support for touch event.
- Adjusted close button for a different look.

## 0.0.4

- Bugfix: if no title, then no caption should be shown.

## 0.0.5

- Bugfix: fix touch.